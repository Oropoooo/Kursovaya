function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
            change.target.classList.add('element-show');
        } else {
            change.target.classList.remove('element-show');
        }
    });
}

let options = {
    threshold: [0.1]
};

let observers = [];

['.container', 'input[type="checkbox"]', '.reserveinput', '.desc', '.reservesubmit'].forEach(selector => {
    let observer = new IntersectionObserver(onEntry, options);
    let elements = document.querySelectorAll(selector);
    elements.forEach(elm => {
        observer.observe(elm);
    });
    observers.push(observer);
});