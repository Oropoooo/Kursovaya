function onEntry(entry) { 
    entry.forEach(change => { 
        if (change.isIntersecting) { 
            change.target.classList.add('element-show'); 
            change.target.querySelector('img').classList.add('small'); // Добавляем класс small для уменьшения размера изображения
        } else { 
            change.target.classList.remove('element-show'); 
            change.target.querySelector('img').classList.remove('small'); // Удаляем класс small для возврата исходного размера изображения
        } 
    }); 
}
 

let options = { 
    threshold: [0.5] 
};

let observers = []; 

['.reviews-ava', '.testimonial', '.your-review', 'input[name="login"]', 'input[name="message"]', 'button', 'label[for="login"]', 'label[for="message"]'].forEach(selector => { 
    let observer = new IntersectionObserver(onEntry, options); 
    let elements = document.querySelectorAll(selector); 
    elements.forEach(elm => { 
        observer.observe(elm); 
    }); 
    observers.push(observer); 
});