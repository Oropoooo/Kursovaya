<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../main/main.css" />
    <link rel="stylesheet" href="../menu/menu.css" />
    <title>Menu</title>
</head>

<body>
    <div class="landing-page">
        <div class="div">
            <div class="div-2">
                <div class="div-2">
                    <div class="overlap">
                        <div class="rectangle"></div>
                        <div class="btn-primary">
                            <a href="../menu/menu.php">
                                <div class="overlap-group">
                                    <div class="group">
                                        <div class="go-to-menu">GO TO MENU</div>
                                        <img class="line" src="../../img/Line-1.svg" />
                                    </div>
                                </div>
                            </a>
                        </div>
                        <p class="taste-the-rich">Taste the rich flavor of<br />high quality sushi</p>
                        <div class="best-sushi-in-town">Best Sushi In Town</div>
                        <p class="we-only-use-the-five">
                            We only use the five star quality for<br />our menu, come and get the richness in<br />every
                            food we
                            serve.
                        </p>
                    </div>
                </div>
                <div class="navbar">
                    <div class="navbar-2">
                        <a href="../menu/menu.php">
                            <div class="text-wrapper-menu">
                                <p class="p-menu">Menu</p>
                            </div>
                        </a>
                        <a href="../reviews/review.php">
                            <div class="text-wrapper-reviews">
                                <p class="p-reviews">Reviews</p>
                            </div>
                        </a>
                        <a href="../about/about.php">
                            <div class="text-wrapper-about">
                                <p class="p-about">About</p>
                            </div>
                        </a>
                        <a href="../staff/staff.php">
                            <div class="text-wrapper-staff">
                                <p class="p-staff">Staff</p>
                            </div>
                        </a>
                        <a href="../suppliers/suppliers.php">
                            <div class="text-wrapper-suppliers">
                                <p class="p-suppliers">Suppliers</p>
                            </div>
                        </a>
                        <a href="../partners/partners.php">
                            <div class="text-wrapper-partners">
                                <p class="p-partners">Partners</p>
                            </div>
                        </a>
                        <a href="../contacts/contacts.php">
                            <div class="text-wrapper-contacts">
                                <p class="p-contacts">Contacts</p>
                            </div>
                        </a>
                    </div>
                    <?php
                    session_start();

                    $userLoggedIn = isset($_SESSION['email']);
                    ?>

                    <?php
                    if ($userLoggedIn) {
                        echo '<a href="/verzakovkursovaya/phps/logout.php" class="group-wrapper-sign-up sign-up">Logout</a>  <a href="../booking/booking.php">
                        <div class="group-wrapper">
                            <div class="group-2">
                                <div class="reservation">RESERVATION</div>
                                <img class="img" src="../../img/line.svg" />
                            </div>
                        </div>
                    </a>';
                    } else {
                        echo '<a href="../sign/signup.php" class="group-wrapper-sign-up sign-up">Sign Up</a> <a href="../sign/signup.php">
                        <div class="group-wrapper">
                            <div class="group-2">
                                <div class="reservation">RESERVATION</div>
                                <img class="img" src="../../img/line.svg" />
                            </div>
                        </div>
                    </a>';
                    }
                    ?>
                    <a href="../main/index.php">
                        <img class="logo" src="../../img/logo-restaurant.png" />
                    </a>
                </div>
            </div>
            <div class="menu">
                <div class="quality-food-for-you">Quality Food For You</div>
                <div class="group-7">
                    <div class="text-wrapper-9">Our Specialities</div>
                    <p class="text-wrapper-10">Authentic food from our restaurant served<br />with high quality
                        ingredients</p>
                </div>
                <div class="groups-show">
                    <div class="group-8-show">
                        <div class="group-8">
                            <p class="text-wrapper-11">
                                Ingredients: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ut imperdiet
                                lectus.
                                Donec
                                vitae vulputate nunc, in laoreet urna.
                            </p>
                            <div class="text-wrapper-12">Dragon Sushi</div>
                            <div class="text-wrapper-13">$50</div>
                        </div>
                        <img class="mask-group-5" src="../../img/sushi10.png" />
                    </div>
                    <div class="group-9-show">
                        <div class="group-9">
                            <p class="text-wrapper-11">
                                Ingredients: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ut imperdiet
                                lectus.
                                Donec
                                vitae vulputate nunc, in laoreet urna.
                            </p>
                            <div class="text-wrapper-12">Roll Salmon Sushi</div>
                            <div class="text-wrapper-13">$50</div>
                        </div>
                        <img class="mask-group-4" src="../../img/sushi11.png" />
                    </div>
                    <div class="group-10-show">
                        <div class="group-10">
                            <p class="text-wrapper-11">
                                Ingredients: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ut imperdiet
                                lectus.
                                Donec
                                vitae vulputate nunc, in laoreet urna.
                            </p>
                            <div class="text-wrapper-12">Creamy Sushi</div>
                            <div class="text-wrapper-13">$50</div>
                        </div>
                        <img class="mask-group-6" src="../../img/sushi12.png" />
                    </div>
                </div>
            </div>
            <div class="dining-events">
                <div class="choose-your-event">Choose Your Event</div>
                <div class="group-19">
                    <div class="text-wrapper-18">Dining Events</div>
                    <p class="text-wrapper-10">We provide dining event for your special day<br />with your important
                        people</p>
                </div>
                <div class="overlap-9">
                    <img class="mask-group-7" src="../../img/finedining2.png" />
                    <div class="rectangle-7"></div>
                    <div class="group-23">
                        <p class="bottle-of-champagne">Bottle of Champagne<br />Fine Sushi Tower For 2+<br />Dessert</p>
                        <p class="div-3"><span class="span">$500 </span> <span class="text-wrapper-21">Fine
                                Dining</span></p>
                    </div>
                </div>
                <div class="overlap-10">
                    <img class="mask-group-8" src="../../img/finedining.png" />
                    <div class="rectangle-8"></div>
                    <div class="group-24">
                        <p class="bottle-of-luxury">
                            Bottle of Luxury Champagne<br />Special Menu Sushi For 2+<br />Royal Dessert
                        </p>
                        <p class="div-3"><span class="span">$1500 </span> <span class="text-wrapper-21">Royalty
                                Dinning</span></p>
                    </div>
                </div>
                <div class="overlap-11">
                    <img class="mask-group-9" src="../../img/luxurybg2.png" />
                    <div class="rectangle-9"></div>
                    <div class="group-25">
                        <div class="overlap-12">
                            <p class="bottle-of-champagne-2">Bottle of Champagne<br />Secret Menu Sushi For
                                2+<br />Dessert</p>
                            <p class="gold-dining">
                                <span class="text-wrapper-23">$1000</span>
                                <span class="text-wrapper-22">Gold Dining&nbsp;&nbsp;</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer">
                <div class="overlap-13">
                    <img class="mask-group-13" src="../../img/finedining3 1.png" />
                    <div class="rectangle-10"></div>
                    <a href="../main/index.php">
                        <img class="logo-2" src="../../img/logo.png" />
                    </a>
                    <?php
                    if ($userLoggedIn) {
                        echo '<a href="../booking/booking.php">
                        <div class="group-29">
                            <div class="overlap-group-4">
                                <div class="text-wrapper-25">Reserve a Table</div>
                            </div>
                        </div>
                    </a>';
                    } else {
                        echo '<a href="../sign/signup.php">
                        <div class="group-29">
                            <div class="overlap-group-4">
                                <div class="text-wrapper-25">Reserve a Table</div>
                            </div>
                        </div>
                    </a>';
                    }
                    ?>
                    <p class="we-ready-to-have-you">We ready to have you <br />the best dining experiences</p>
                    <div class="group-30">
                        <div class="group-31">
                            <p class="text-wrapper-26">Jendral Sudirman Street Pahoman<br />Bandar Lampung, Lampung,
                                35222</p>
                            <img class="map-pin-fill" src="../../img/map-pin-fill.svg" />
                        </div>
                        <div class="group-32">
                            <div class="text-wrapper-26">Call us:<br />+0721 471 285</div>
                            <img class="phone-fill" src="../../img/phone-fill.svg" />
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="menu.js"></script>
</body>

</html>