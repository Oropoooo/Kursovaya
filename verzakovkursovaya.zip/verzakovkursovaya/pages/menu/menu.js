function onEntry(entry) { 
    entry.forEach(change => { 
        if (change.isIntersecting) { 
            change.target.classList.add('element-show'); 
        } else { 
            change.target.classList.remove('element-show'); 
        } 
    }); 
} 

let options = { 
    threshold: [0.4] 
};

let options2 = { 
    threshold: [0.7] 
};

let observers = []; 

['.group-8-show', '.group-9-show', '.group-10-show'].forEach(selector => { 
    let observer = new IntersectionObserver(onEntry, options); 
    let elements = document.querySelectorAll(selector); 
    elements.forEach(elm => { 
        observer.observe(elm); 
    }); 
    observers.push(observer); 
});

['.mask-group-7', '.mask-group-8', '.mask-group-9'].forEach(selector => { 
    let observer = new IntersectionObserver(onEntry, options2); 
    let elements = document.querySelectorAll(selector); 
    elements.forEach(elm => { 
        observer.observe(elm); 
    }); 
    observers.push(observer); 
});
