function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
            change.target.classList.add('element-show');
        } else {
            change.target.classList.remove('element-show');
        }
    });
}

let options = {
    threshold: [0.7]
};

let observers = [];

['.suppliers-text', '.shadow'].forEach(selector => {
    let observer = new IntersectionObserver(onEntry, options);
    let elements = document.querySelectorAll(selector);
    elements.forEach(elm => {
        observer.observe(elm);
    });
    observers.push(observer);
});