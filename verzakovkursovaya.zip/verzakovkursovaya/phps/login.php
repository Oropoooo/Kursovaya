<?php
session_start();

require_once('../phps/db.php');

$email = $_POST['email'];
$pass = $_POST['pass'];

$sql = "SELECT * FROM users WHERE email = '$email' AND pass = '$pass'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Если пользователь вошел успешно, сохраняем его email в сессии
    $_SESSION['email'] = $email;

    header('Location: /verzakovkursovaya/pages/booking/bookingsec.php');
    exit();
} else {
    echo '';
}
?>