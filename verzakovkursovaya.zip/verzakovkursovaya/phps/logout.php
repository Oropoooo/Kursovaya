<?php
session_start();

// Уничтожаем все данные сессии
session_destroy();

// Перенаправляем пользователя на главную страницу или на любую другую страницу
header('Location: /verzakovkursovaya/pages/main/index.php');
exit();
?>