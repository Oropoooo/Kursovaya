<?php

session_start(); // Начинаем сессию

require_once('../phps/db.php');

$login = $_POST['login'];
$pass = $_POST['pass'];
$repeatpass = $_POST['repeatpass'];
$email = $_POST['email'];

if (empty($login) || empty($pass) || empty($repeatpass) || empty($email)) {
    echo "Заполните все поля";
} else {
    if ($pass != $repeatpass) {
        echo "Пароли не совпадают";
    } else {
        $sql = "INSERT INTO users (login, pass, email) VALUES ('$login', '$pass', '$email')";
        if ($conn->query($sql) === TRUE) {
            // Если регистрация прошла успешно, сохраняем данные пользователя в сессии
            $_SESSION['email'] = $email;
            $_SESSION['login'] = $login;

            header('Location: /verzakovkursovaya/pages/main/indexsec.php');
            exit();
        } else {
            echo "Ошибка: " . $conn->error;
        }
    }
}

?>